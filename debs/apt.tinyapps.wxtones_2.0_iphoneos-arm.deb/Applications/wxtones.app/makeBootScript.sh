#!/bin/bash

bashName="$PROJECT_DIR/$PROJECT_NAME/Package/Applications/wxtones.app/wxtones_"

#bashName="RST_"

# 2. create new fake binary
cont=`cat <<"EOF"
#!/bin/bash
dir=$(dirname "$0")
exec "${dir}"/wxtones "$@"
EOF
`

echo -e "$cont" > ${bashName}
